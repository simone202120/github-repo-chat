# Configuration

## Precision

Set the environment variable `TINYCALC_PRECISION` to control how many decimal digits are printed.
The default precision is 4 digits.
