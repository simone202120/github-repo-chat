# tinycalc

tinycalc is a tiny command-line calculator used as a test fixture.

## Installation

Install it with pip:

```bash
pip install tinycalc
```

## Usage

Run `tinycalc add 2 3` to print the sum of two numbers.
Division by zero raises `DivisionByZeroError`.
