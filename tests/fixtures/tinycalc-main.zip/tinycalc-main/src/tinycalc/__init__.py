"""tinycalc package."""
