"""Arithmetic operations."""


class DivisionByZeroError(ValueError):
    """Raised when dividing by zero."""


class Calculator:
    """Performs arithmetic with a configurable precision."""

    def __init__(self, precision: int = 4) -> None:
        self.precision = precision

    def add(self, a: float, b: float) -> float:
        """Returns the sum of a and b rounded to the configured precision."""
        return round(a + b, self.precision)

    def divide(self, a: float, b: float) -> float:
        """Divides a by b, raising DivisionByZeroError when b is zero."""
        if b == 0:
            raise DivisionByZeroError("cannot divide by zero")
        return round(a / b, self.precision)
