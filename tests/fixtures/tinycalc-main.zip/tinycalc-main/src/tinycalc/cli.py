"""Command-line entry point."""

import os
import sys

from tinycalc.calculator import Calculator


def main(argv: list[str]) -> None:
    precision = int(os.environ.get("TINYCALC_PRECISION", "4"))
    calculator = Calculator(precision)
    operation, a, b = argv[0], float(argv[1]), float(argv[2])
    print(getattr(calculator, operation)(a, b))


if __name__ == "__main__":
    main(sys.argv[1:])
